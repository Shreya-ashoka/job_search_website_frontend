ONLINE JOB PORTAL USING REACT AND SANITY


This website is all about searching the top jobs from top-reputed companies all over the world.
It has additional functionalities of searching and filter jobs on based of their job role or experience.
Further more it has a form where a company user who wants to add their job on to our site can fill the form and add it.
Next, it has an option where a student/user can save the job by clicking on bookmark icon.


Now one surprise section added is of discussion Chamber which is connected with Sanity(Headless CMS).
A text-editor is added with functionalities of bold,italic,etc and image section where a user can just upload an image or can copy any image address from wherever and it will automatically preview image according to the type of input url using regex.
User can reply the same thing as well at the same time.

This website is fullt responsive..




Home Page

![Screenshot 2023-01-28 at 8 49 15 PM](https://user-images.githubusercontent.com/114575434/215274848-ce9787c7-8bdc-43c5-9f58-f7862b4cecd7.png)


Jobs Page

![Screenshot 2023-01-28 at 8 47 22 PM](https://user-images.githubusercontent.com/114575434/215274857-f2aefecd-f349-4c8c-b703-0c4ad410159a.png)



Job Category Filter


![Screenshot 2023-01-28 at 8 47 22 PM](https://user-images.githubusercontent.com/114575434/215274869-908a1630-83c9-44c6-bf37-dfb76262a895.png)



Discussion Chamber

![Screenshot 2023-01-28 at 8 52 19 PM](https://user-images.githubusercontent.com/114575434/215274887-06fa1c2e-79b1-47f0-b0ee-bdb34d6f1281.png)





Tools and Technology Used:-

1.HTML CSS AND JS
2.React JS
3.Sanity for Backend.
4.VS Code
5.Vercel for deployment.
