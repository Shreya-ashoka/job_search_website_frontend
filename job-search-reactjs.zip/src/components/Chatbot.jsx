// Chatbot.jsx

import React, { useState } from 'react';

const Chatbot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const handleSendMessage = () => {
    if (input.trim() === '') return;

    const newMessages = [...messages, { text: input, type: 'user' }];
    setMessages(newMessages);

    // Simulate a response from the chatbot
    simulateChatbotResponse(input);

    // Clear the input field
    setInput('');
  };

  const simulateChatbotResponse = (userMessage) => {
    // In a real-world scenario, you would make an API call to a backend server or use a natural language processing (NLP) library for more advanced responses.
    const suggestions = getJobSuggestions(userMessage);
    const botResponse = `Chatbot: Thanks for your message - "${userMessage}"! Here are some job-related suggestions: ${suggestions}`;

    const newMessages = [...messages, { text: botResponse, type: 'bot' }];
    setMessages(newMessages);
  };

  const getJobSuggestions = (userMessage) => {
    // In a real-world scenario, you might fetch job suggestions from an external API or database.
    // For simplicity, we'll use a static list here.
    const jobSuggestions = ['Software Developer', 'Data Analyst', 'Marketing Specialist', 'UX/UI Designer'];
    return jobSuggestions.join(', ');
  };

  return (
    <div>
      <div className="message-container">
        {messages.map((msg, index) => (
          <div key={index} className={`message ${msg.type}`}>
            {msg.text}
          </div>
        ))}
      </div>
      <div className="input-container">
        <input type="text" value={input} onChange={handleInputChange} />
        <button onClick={handleSendMessage}>Send</button>
      </div>
    </div>
  );
};

export default Chatbot;
