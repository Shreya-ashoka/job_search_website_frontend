import React, { useState } from "react";

const ResumeForm = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    education: "",
    degree: "",
    graduationYear: "",
    workExperience: "",
    position: "",
    company: "",
    experienceYear: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>First Name:</label>
        <input type="text" name="firstName" value={formData.firstName} onChange={handleChange} required />
      </div>

      <div>
        <label>Last Name:</label>
        <input type="text" name="lastName" value={formData.lastName} onChange={handleChange} required />
      </div>

      <div>
        <label>Email:</label>
        <input type="email" name="email" value={formData.email} onChange={handleChange} required />
      </div>

      <div>
        <label>Phone:</label>
        <input type="tel" name="phone" value={formData.phone} onChange={handleChange} required />
      </div>

      <div>
        <h2>Education</h2>
        <label>School/University:</label>
        <input type="text" name="education" value={formData.education} onChange={handleChange} required />

        <label>Degree:</label>
        <input type="text" name="degree" value={formData.degree} onChange={handleChange} required />

        <label>Graduation Year:</label>
        <input type="text" name="graduationYear" value={formData.graduationYear} onChange={handleChange} required />
      </div>

      <div>
        <h2>Work Experience</h2>
        <label>Position:</label>
        <input type="text" name="position" value={formData.position} onChange={handleChange} required />

        <label>Company:</label>
        <input type="text" name="company" value={formData.company} onChange={handleChange} required />

        <label>Experience Year:</label>
        <input type="text" name="experienceYear" value={formData.experienceYear} onChange={handleChange} required />
      </div>
    
      <button type="submit">Submit</button>
    </form>
  );
};

export default ResumeForm;
